Account API removed
-------------------

The 'account' API was deprecated in v0.17 and has been fully removed in v0.18.
The 'label' API was introduced in v0.17 as a replacement for accounts.

See the release notes from v0.17 for a full description of the changes from the
'account' API to the 'label' API.

addwitnessaddress RPC method removed
------------------------------------

The `addwitnessaddress` RPC was added for segwit testing in version 0.13.0. It
was deprecated in version 0.16.0. This version fully removes the RPC method.
